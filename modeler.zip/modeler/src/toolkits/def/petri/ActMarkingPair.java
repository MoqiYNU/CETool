package toolkits.def.petri;

/**
 * @author Moqi
 * ����(�,��ʶ)
 */
public class ActMarkingPair {
	
	private String act;
	private Marking marking;
	
	public String getAct() {
		return act;
	}
	public void setAct(String act) {
		this.act = act;
	}
	public Marking getMarking() {
		return marking;
	}
	public void setMarking(Marking marking) {
		this.marking = marking;
	}

}
