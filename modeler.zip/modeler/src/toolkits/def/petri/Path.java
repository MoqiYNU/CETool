package toolkits.def.petri;

import java.util.List;

/**
 * @author Moqi
 * ����ɴ�ͼ��·��
 */
public class Path {
	
	@SuppressWarnings("rawtypes")
	private List sequence;

	@SuppressWarnings("rawtypes")
	public List getSequence() {
		return sequence;
	}

	@SuppressWarnings("rawtypes")
	public void setSequence(List sequence) {
		this.sequence = sequence;
	}
	
}
