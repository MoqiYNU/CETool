package toolkits.utils.block;

/**
 * @author Moqi 
 * ����˳����б�Ǩ��
 */
public class SEQPair {
	
	private String preAct;
	private String succAct;
	
	public String getPreAct() {
		return preAct;
	}
	public void setPreAct(String preAct) {
		this.preAct = preAct;
	}
	public String getSuccAct() {
		return succAct;
	}
	public void setSuccAct(String succAct) {
		this.succAct = succAct;
	}

}
